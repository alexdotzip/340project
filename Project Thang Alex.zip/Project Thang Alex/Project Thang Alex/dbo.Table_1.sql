﻿CREATE TABLE [dbo].[Customers]
(
	[customerid] INT NOT NULL PRIMARY KEY, 
    [customerFName] VARCHAR(50) NULL, 
    [customerLName] VARCHAR(50) NULL, 
    [customerIllness] VARCHAR(50) NULL, 
    [prescriptionID] INT NULL
)
